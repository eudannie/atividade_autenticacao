# app_links_linux

Linux platform implementation of [app_links](https://pub.dev/packages/app_links) plugin.