import 'desktop_webview_auth_platform_interface.dart';

/// Stub implementation for [DesktopWebviewAuthPlatform]
class MethodChannelDesktopWebviewAuth extends DesktopWebviewAuthPlatform {}
