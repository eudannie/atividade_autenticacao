#import <Flutter/Flutter.h>

@interface DesktopWebviewAuthPlugin : NSObject<FlutterPlugin>
@end
