package com.example.firezin

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
