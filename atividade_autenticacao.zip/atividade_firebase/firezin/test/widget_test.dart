// Este é um teste básico de widget do Flutter.
//
// Para realizar uma interação com um widget no seu teste, use a utilidade
// WidgetTester no pacote flutter_test. Por exemplo, você pode enviar gestos de
// toque e rolagem. Você também pode usar WidgetTester para encontrar widgets
// filhos na árvore de widgets, ler texto e verificar se os valores das
// propriedades do widget estão corretos.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart'; // O import está correto aqui.
import 'package:firezin/app.dart'; // Você também pode precisar importar o app.dart

void main() {
  // Teste para o MyApp
  testWidgets('Testa se o MyApp é renderizado', (WidgetTester tester) async {
    // 1. Chame o MyApp, passando o clientId.
    await tester.pumpWidget(const MyApp(clientId: 'TEST_CLIENT_ID'));

    // 2. Verifique se o texto 'Olá, Flutter!' é exibido na tela.
    // Lembre-se de que este texto deve estar presente no seu app.dart.
    expect(find.text('Olá, Flutter!'), findsOneWidget);
  });

  // Teste para a função de contador
  testWidgets('Testa se o contador incrementa', (WidgetTester tester) async {
    // Renderize o widget principal do seu app para este teste.
    await tester.pumpWidget(const MyApp(clientId: 'TEST_CLIENT_ID'));
    
    // Verifique se o contador começa em 0.
    expect(find.text('0'), findsOneWidget);
    expect(find.text('1'), findsNothing);

    // Toque no ícone '+' e dispare um frame.
    await tester.tap(find.byIcon(Icons.add));
    await tester.pump();

    // Verifique se o contador foi incrementado para 1.
    expect(find.text('0'), findsNothing);
    expect(find.text('1'), findsOneWidget);
  });
}